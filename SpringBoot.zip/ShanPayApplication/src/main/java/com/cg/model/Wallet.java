package com.cg.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name="WalletBoot")
public class Wallet implements Serializable{
	private static final long serialVersionUID = 1L;
	
	
	@Id
	@GeneratedValue(generator="sserr",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="sserr",sequenceName="walletseqr",initialValue=100,allocationSize=1)
	int walletid;
	
	BigDecimal balance;

	public Wallet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Wallet(int walletid, BigDecimal balance) {
		super();
		this.walletid = walletid;
		this.balance = balance;
	}

	public int getWalletid() {
		return walletid;
	}

	public void setWalletid(int walletid) {
		this.walletid = walletid;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Wallet [walletid=" + walletid + ", balance=" + balance + "]";
	}
	
	

}
