package com.cg.model;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;


@Component
@Entity
@Table(name="CustomerBoot")
public class Customer implements Serializable 
{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(generator = "cerww", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "cerww", sequenceName = "cseqww", initialValue = 100, allocationSize = 1)
	private int cid;
	private String Cname;
	private String mobilenum;
	private String password;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "walletid")
	
	Wallet wallet;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Wallet getWallet() {
		return wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCname() {
		return Cname;
	}

	public void setCname(String cname) {
		Cname = cname;
	}

	public String getMobilenum() {
		return mobilenum;
	}

	public void setMobilenum(String mobilenum) {
		this.mobilenum = mobilenum;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Customer [Cname=" + Cname + ", mobilenum=" + mobilenum + "]";
	}

	
}