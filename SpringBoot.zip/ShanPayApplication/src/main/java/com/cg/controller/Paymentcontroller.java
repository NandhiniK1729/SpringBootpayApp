package com.cg.controller;

import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.model.Customer;
import com.cg.service.WalletService;

@Controller
public class Paymentcontroller {
	@Autowired
	WalletService service;

	Customer c2 = null;
	public Paymentcontroller() {
		System.out.println("hello controller");
	}
	@RequestMapping("/createcustomer")
	public String addCustomer() {

		return "customerform";
	}
	@RequestMapping("/")
	public String index1()
	{
		return "index";
	}
	@RequestMapping("/logincustomer")
	public String loginCustomer(HttpServletRequest request) 
	{
		HttpSession session = request.getSession();
		session.setAttribute("status", "");
		return "loginform";
	}

	@RequestMapping("/save")
	public ModelAndView addProduct(HttpServletRequest request) {
		HttpSession session = request.getSession();
		ModelAndView modelView = new ModelAndView();
		String name = request.getParameter("Cname");
		String mobileno = request.getParameter("mobilenum");
		String password= request.getParameter("password");
		BigDecimal amount1 = new BigDecimal(request.getParameter("amount"));
		Customer c = service.createAccount(name, mobileno, amount1,password);
		if (c != null) 
		{
			session.setAttribute("status", "Successfully registered");
			modelView.setViewName("loginform");
		} else
		{
			session.setAttribute("status", "Mobile number already Exists...");
			modelView.setViewName("customerform");
		}
		return modelView;
	}

	@RequestMapping("/log")
	public ModelAndView login(HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		ModelAndView modelView = new ModelAndView();
		String mobileno = request.getParameter("mobilenum");
		String password=request.getParameter("password");
		c2 = service.validate(mobileno,password);
		if (c2 != null) {
			session.setAttribute("cname", c2.getCname());
			session.setAttribute("balance", c2.getWallet());
			session.setAttribute("mobile", c2.getMobilenum());
			modelView.setViewName("home");
		} else {
			session.setAttribute("status", "Invalid Mobile number/Password");
			modelView.setViewName("loginform");
		}
		return modelView;

	}

	@RequestMapping("/viewcustomer")
	public String viewAllCustomer() {
		return "viewcustomer";
	}

	@RequestMapping("/showbalance")
    public ModelAndView bal(HttpServletRequest request)
    {
		HttpSession session=request.getSession();
		ModelAndView modelView=new ModelAndView();
        Customer c=service.showBalance(c2.getMobilenum());
        session.setAttribute("balance",c.getWallet().getBalance());
        session.setAttribute("status", "Your Account Balance is ");
        modelView.setViewName("showbalance");    
        return modelView;
    }
	@RequestMapping("/withdraw")
	public String withdraw(HttpServletRequest request) 
	{
		HttpSession session = request.getSession();
		session.setAttribute("status", "");
		return "withdraw";
	}

	@RequestMapping("/with")
	public ModelAndView with(HttpServletRequest request) {
		HttpSession session = request.getSession();
		ModelAndView modelView = new ModelAndView();
		String amount = request.getParameter("wamount");
		BigDecimal b = new BigDecimal(amount);
		if(b.compareTo(c2.getWallet().getBalance())!=1)
		{
			Customer c = service.withdrawAmount(c2.getMobilenum(), b);
			session.setAttribute("balance", c.getWallet().getBalance());
			session.setAttribute("status", "Withdrawn Successfully...Your Account Balance is ");
			modelView.setViewName("showbalance");
		}
		else
		{
			session.setAttribute("status", "Not enough Balance");
			modelView.setViewName("withdraw");
	
		}
		return modelView;
	}

	@RequestMapping("/deposit")
	public String depo() 
	{
		return "deposit";
	}

	@RequestMapping("/depo")
	public ModelAndView depo(HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		ModelAndView modelView = new ModelAndView();
		String amount = request.getParameter("damount");
		BigDecimal b = new BigDecimal(amount);
		Customer c = service.depositAmount(c2.getMobilenum(), b);
		session.setAttribute("balance", c.getWallet().getBalance());
		session.setAttribute("status", "Deposited Successfully...Your Account Balance is ");
		modelView.setViewName("showbalance");
		return modelView;
	}

	@RequestMapping("/fundtransfer")
	public String fund(HttpServletRequest request) 
	{
		HttpSession session = request.getSession();
		session.setAttribute("status", "");
		return "fundtransfer";
	}

	@RequestMapping("/trans")
	public ModelAndView transfer(HttpServletRequest request) {
		HttpSession session = request.getSession();
		ModelAndView modelView = new ModelAndView();
		String tnum = request.getParameter("tnum");
		String tamnt = request.getParameter("tamount");
		BigDecimal b1 = new BigDecimal(tamnt);
		if(b1.compareTo(c2.getWallet().getBalance())!=1)
		{
			Customer c = service.fundTransfer(c2.getMobilenum(), tnum, b1);
			session.setAttribute("status", "Amount Tranfered Successfully...Your Account Balance is ");
			session.setAttribute("balance", c.getWallet().getBalance());
			modelView.setViewName("showbalance");
			
		}
		else
		{
			session.setAttribute("status", "Not enough Balance");
			modelView.setViewName("fundtransfer");
		}
		return modelView;
	}

	@RequestMapping("/logout")
	public String admin()
	{
		return "logoutform";
	}

	@RequestMapping("/adminlog")
	public ModelAndView adminlog(HttpServletRequest request, Model map) {
		HttpSession session = request.getSession();
		ModelAndView modelView = new ModelAndView();

		String user = request.getParameter("uname");
		String password = request.getParameter("pwd");
		if ((user.equals("admin")) && (password.equals("admin"))) {
			List<Customer> list = service.getAllCustomer();
			session.setAttribute("clist", list);
			modelView.setViewName("viewcustomer");
		}
		return modelView;
	}
	@RequestMapping("/home")
	public String home()
	{
		return "home";
	}
	@RequestMapping("/about")
	public String about() {
		return "aboutform";
	}

}
