package com.cg.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.model.Customer;
import com.cg.model.Wallet;
import com.cg.repo.WalletRepo;
@Service("customerService")
public class WalletServiceImpl implements WalletService
{
   @Autowired
   WalletRepo repo;

	@Override
	public Customer createAccount(String name, String mobileno, BigDecimal amount,String password)
	{
		// TODO Auto-generated method stub
		Customer f=new Customer();
		f=repo.findBymobilenum(mobileno);
		if(f==null)
		{
		Customer c=new Customer();
		c.setCname(name);
		c.setMobilenum(mobileno);
		c.setPassword(password);
		Wallet w=new Wallet();
		w.setBalance(amount);
		c.setWallet(w);
		repo.save(c);
		return c;
		}
		else
		{
		return null;
		}
	}

	@Override
	public Customer showBalance(String mobileno) {
		// TODO Auto-generated method stub
		Customer c=repo.findBymobilenum(mobileno);
		return c;
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		Customer c1=repo.findBymobilenum(sourceMobileNo);
		Customer c2=repo.findBymobilenum(targetMobileNo);
		BigDecimal b1=c1.getWallet().getBalance();
		BigDecimal b2=c2.getWallet().getBalance();
        b1=b1.subtract(amount);
        b2=b2.add(amount);
        Wallet w1=new Wallet();
        w1.setBalance(b1);
        Wallet w2=new Wallet();
        w2.setBalance(b2);
        c1.setWallet(w1);
        c2.setWallet(w2);
        repo.save(c1);
        repo.save(c2);
		return c1;
	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount)
	{
		Customer c4=null;
		c4=repo.findBymobilenum(mobileNo);
		BigDecimal b1=c4.getWallet().getBalance();
		b1=b1.add(amount);
		Wallet w=new Wallet();
		w.setBalance(b1);
		c4.setWallet(w);
		repo.save(c4);
		return c4;
		
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) 
	{         
		Customer c4;
		System.out.println(mobileNo);
		c4=repo.findBymobilenum(mobileNo);
		System.out.println(c4);
		BigDecimal b1=c4.getWallet().getBalance();
		System.out.println("Balance   "+b1);
		b1=b1.subtract(amount);
		Wallet w=new Wallet();
		w.setBalance(b1);
		c4.setWallet(w);
		//System.out.println(c4,w);
		repo.save(c4);
		return c4;
		
		
     }
	public Customer validate(String mobilenum,String password)
	{
       Customer c=repo.findBymobilenum(mobilenum) ;
       if(c.getPassword().equals(password)&&c!=null)
       {
       return c;
       }
       else
       {
    	   return null;
       }
	}
	public List<Customer> getAllCustomer()
	{
		List<Customer> l1=repo.findAll();
				return l1;
	}
    
	

}
