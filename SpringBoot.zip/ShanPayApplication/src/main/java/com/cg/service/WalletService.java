package com.cg.service;

import java.math.BigDecimal;
import java.util.List;

import com.cg.model.Customer;

public interface WalletService {
	public Customer createAccount(String name ,String mobileno, BigDecimal amount,String password);
	public Customer showBalance (String mobileno);
	public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, BigDecimal amount);
	public Customer depositAmount (String mobileNo,BigDecimal amount );
	public Customer withdrawAmount(String mobileNo, BigDecimal amount);
	public Customer validate(String mobilenum,String password);
	public List<Customer> getAllCustomer();

}
