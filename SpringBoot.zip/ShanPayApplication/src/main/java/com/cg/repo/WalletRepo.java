package com.cg.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.model.Customer;

public interface WalletRepo extends  JpaRepository<Customer,String>{
	public Customer findBymobilenum(String mobilenum);
	//public Customer findBymobilenum(String mobilenum,String password);

}